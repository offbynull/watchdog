import com.offbynull.watchdog.user.Watch;

@Watch
public class RecursiveClassAnnotationTest {
	public RecursiveClassAnnotationTest() {
		recurse();
	}
	
	private void recurse() {
		sleep(1L);
		recurse();
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
