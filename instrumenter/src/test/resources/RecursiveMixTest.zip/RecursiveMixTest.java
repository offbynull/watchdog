import com.offbynull.watchdog.user.Watch;
import com.offbynull.watchdog.user.Watchdog;

public class RecursiveMixTest {

	@Watch
	public RecursiveMixTest() {
		recurse(Watchdog.PLACEHOLDER);
	}
	
	private void recurse(Watchdog watchdog) {
		sleep(1L);
		recurse(watchdog);
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
