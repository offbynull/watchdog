import com.offbynull.watchdog.user.Watch;
import com.offbynull.watchdog.user.Watchdog;

public class RecursiveMixSameMethodTest {

	public RecursiveMixSameMethodTest() {
		recurse(Watchdog.PLACEHOLDER);
	}
	
	@Watch
	private void recurse(Watchdog watchdog) {
		sleep(1L);
		recurse(watchdog);
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
