import com.offbynull.watchdog.user.Watchdog;

public class TableSwitchTest {
	public TableSwitchTest(Watchdog watchdog) {
		int y=0;
		sleep(500L);
		switch (y%2) {
		case 0:
			throw new RuntimeException("0");
		case 1:
			throw new RuntimeException("1");
		default:
			throw new RuntimeException("nope");
		}		
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
