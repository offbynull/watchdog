import com.offbynull.watchdog.user.Watchdog;

public class TableSwitchTest {
	public TableSwitchTest(Watchdog watchdog) {
		tableSwitch(watchdog, 0);
	}
	
	private void tableSwitch(Watchdog watchdog, int y) {
		sleep(500L);
		switch (y%2) {
		case 0:
			tableSwitch(watchdog, y+1);
			break;
		case 1:
			tableSwitch(watchdog, y+1);
			break;
		default:
			throw new RuntimeException("nope");
		}		
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
