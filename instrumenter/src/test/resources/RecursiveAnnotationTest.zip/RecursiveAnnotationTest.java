import com.offbynull.watchdog.user.Watch;

public class RecursiveAnnotationTest {
	@Watch
	public RecursiveAnnotationTest() {
		recurse();
	}
	
	@Watch
	private void recurse() {
		sleep(1L);
		recurse();
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
