import com.offbynull.watchdog.user.Watchdog;

public class TightLoopTest {
	public TightLoopTest(Watchdog watchdog) {
		int i = 0;
		while (i == 0) {
			// some garbage code -- does nothing
			i += 1;
			i -= 1;
		}
	}
}