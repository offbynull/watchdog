import com.offbynull.watchdog.user.Watchdog;

public class TightLoopTest {
	public TightLoopTest(Watchdog watchdog) {
		while (true) {
			staticLoop(watchdog, 100);
			normalLoop(watchdog, 100);
		}
	}
	
	private static void staticLoop(Watchdog watchdog, int x) {
		for (int i = 0; i < x; i++) {
			// some garbage code -- does nothing 
			i += 1;
			i -= 1;
		}
	}

	private static void normalLoop(Watchdog watchdog, int y) {
		for (int i = 0; i < y; i++) {
			// some garbage code -- does nothing
			i += 1;
			i -= 1;
		}		
	}
}
