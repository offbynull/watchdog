import com.offbynull.watchdog.user.Watchdog;

public class InstantiationTest {
	public InstantiationTest(Watchdog watchdog) {
		Boolean b = new Boolean(false);
		Byte by = new Byte((byte) 1);
		Character c = new Character((char) 2);
		Short s = new Short((short) 3);
		Integer i = new Integer(4);
		Long l = new Long(5L);
		Float f = new Float(0.2f);
		Double d = new Double(0.7);
		Object sc = new StandaloneClass("ggg", 0.1f, 1.1);
		Object cc = new ChildClass((char) 5, "fff", null, "zzz");
		Object ia = new int[5];
		Object iaa = new int[5][5];
		Object oa = new Object[5];
		Object oaa = new Object[5][5];
//		Object x = new Integer(1);
//		Object z = new Integer(2);
//		Object y = new Long(5L);
//		Object t = new String("aaaaaa");
	}
	
	private static final class StandaloneClass {
		public StandaloneClass(Object a, float x, double y) {
			
		}
	}
	
	private static final class ChildClass {
		public ChildClass(char x, Object j, Object i, Object k) {
			
		}
	}
}
