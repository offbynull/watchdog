import com.offbynull.watchdog.user.Watchdog;
import com.offbynull.watchdog.user.WatchdogLauncher;

public class RecursiveWatchTest {
	public RecursiveWatchTest(Watchdog watchdog) throws Exception {
		WatchdogLauncher.watch(1000L, (wd) -> new RecursiveWatchTest(wd));
	}

}
