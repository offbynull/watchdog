
public class StaticMethodTest {
    public void noStatic(int x) {
    }

    private static void yesStatic(long y) {
    }
}
