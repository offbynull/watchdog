import com.offbynull.watchdog.user.Watchdog;

public class RecursiveTest {
	public RecursiveTest(Watchdog watchdog) {
		recurse(watchdog);
	}
	
	private void recurse(Watchdog watchdog) {
		sleep(1L);
		recurse(watchdog);
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
