import com.offbynull.watchdog.user.Watch;

public class LookupSwitchAnnotationTest {
	@Watch
	public LookupSwitchAnnotationTest() {
		int y=0;
		sleep(500L);
		switch ((y%2) * 10000000) {
		case 0:
			throw new RuntimeException("0");
		case 10000000:
			throw new RuntimeException("1");
		default:
			throw new RuntimeException("nope");
		}
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
