import com.offbynull.watchdog.user.Watchdog;

public class LookupSwitchTest {
	public LookupSwitchTest(Watchdog watchdog) {
		lookupSwitch(watchdog, 0);
	}
	
	private void lookupSwitch(Watchdog watchdog, int y) {
		sleep(500L);
		switch ((y%2) * 10000000) {
		case 0:
			lookupSwitch(watchdog, y+1);
			sleep(1L);
			break;
		case 10000000:
			lookupSwitch(watchdog, y+1);
			sleep(1L);
			break;
		default:
			throw new RuntimeException("nope");
		}	
	}
	
	private void sleep(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException ie) {
			throw new RuntimeException(ie);
		}
	}
}
