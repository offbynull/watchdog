import com.offbynull.watchdog.user.Watch;
import com.offbynull.watchdog.user.Watchdog;

public class DoubleInstrumentationTest {
	
	@Watch
	public static void test(Watchdog watchdog) {
		int i = 1;
		while (true) {
			i++;
			i--;
			if (i == 0) {
				break;
			}
		}
	}
}
