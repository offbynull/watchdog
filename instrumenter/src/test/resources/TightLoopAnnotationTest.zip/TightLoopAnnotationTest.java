import com.offbynull.watchdog.user.Watch;

public class TightLoopAnnotationTest {
	@Watch
	public TightLoopAnnotationTest() {
		int i = 0;
		while (i == 0) {
			// some garbage code -- does nothing
			i += 1;
			i -= 1;
		}
	}
}